#!/usr/local/bin/python3

import sys, os

os.system('./start_app.sh')